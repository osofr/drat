library(testthat)
library(h2oEnsemble)
library(cvAUC)

test_check("h2oEnsemble")
